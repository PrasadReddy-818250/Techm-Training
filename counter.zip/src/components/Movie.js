import React from "react";


const Movie = ({name,hrname}) => {
    return(
        <div>
            <h3>Movie: {name}</h3>
            <p>Hero: {hrname}</p>
        
        </div>
    );
}

export default Movie;