import React,{useState, useContext} from "react";
import Movie from "./Movie";
import { MovieContext } from "./MovieContext";

const MovieList = () => {
   //const value = useContext(MovieContext);
   const [movies,setMovies] = useContext(MovieContext);
    return(
        <div>
            <h1 className="text-danger mt-4">Your List</h1>
           
            {movies.map(movie => (
                
                <Movie name={movie.name} hrname={movie.hrname}/>
            ))}
        </div>
    );
}

export default MovieList;