import React from "react";
import {useSelector, useDispatch} from "react-redux";
import {increment, reset , addMovie,removeMovies} from "./actions/index"

function App() {
  const counter = useSelector(state => state.counter);
  const isLogged = useSelector(state => state.isLogged);
  const moviecount = useSelector(state => state.moviecount);
  const dispatch = useDispatch();
  return (
    <div className="App" >
      <h1 class=" text-white bg-primary" > React-application</h1>
      <hr/>
      <h2>Using React_Redux</h2>
      <hr/>
      <h1>Number Of Heroes : {counter}</h1>
      <button onClick={ () => dispatch(increment()) }>ADD HERO</button>
      <button onClick={ () => dispatch(reset()) }>RESET</button>
      <h1>Number Of Movies : {moviecount}</h1>
      <button onClick={ () => dispatch(addMovie()) }>ADD Movie</button>
      <button onClick={ () => dispatch(removeMovies()) }>RESET</button>
      {isLogged ? <h3>Valuable Information I shouldn't see</h3> : ""}
      
    </div>
  );
}

export default App;
