import React,{useState , createContext} from "react";

export const MovieContext = createContext();

export const MovieProvider = (props) => {
    const [movies, setMovies] = useState([
        {
            name: 'Harry Potter',
            hrname: 'Daniel',
            
        },
        {
            name: 'Aquaman',
            hrname: 'Jason',
            
        },
        {
            name: 'Spiderman',
            hrname: 'Tobey',
            
        }
    ])
    return(
        <MovieContext.Provider value={[movies,setMovies]}>
            {props.children}
        </MovieContext.Provider>
    );
}