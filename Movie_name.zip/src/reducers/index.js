import counterReducer from "./counter"
import counterMovieReducer from "./movieCount";
import { combineReducers } from "redux";

const allReducers = combineReducers({
    counter: counterReducer,
    moviecount: counterMovieReducer
});

export default allReducers;