import MovieList from "./components/MovieLists";
import Navbar from "./components/Nav";
import AddMovie from "./AddMovie";
import { MovieProvider } from "./components/MovieContext";

function App() {
  return (
    <MovieProvider>
      <div className="App">
      <Navbar/>
        <div className="container mt-4">
            <b>Enter and view Details</b>
            <hr/>
            <AddMovie/>
            <MovieList/>
            
        </div>
      </div>
    </MovieProvider>
    
  );
}

export default App;
