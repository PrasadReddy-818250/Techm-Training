export const increment = (num) => {
    return {
        type: 'INCREMENT'
    };
}

export const reset = () => {
    return {
        type: 'RESET'
    };
}

export const addMovie = () => {
    return {
        type:'ADDMOVIE'
    };
}
export const removeMovies = () => {
    return {
        type:'REMOVEMOVIES'
    };
}