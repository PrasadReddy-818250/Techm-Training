import React, {useState,useContext} from "react";
import { MovieContext } from "./components/MovieContext";

const AddMovie = () => {
    const [name,setName] = useState('');
    const [Hrname,sethrname] = useState('');
    const [movie,setMovies] = useContext(MovieContext);

    const updateName = (e) => {
        setName(e.target.value);
    }
    const updateHname = (e) => {
        sethrname(e.target.value);
    }

    const addMovie = (e) => {
        e.preventDefault();
        setMovies(prevMovie => [...prevMovie,{name:name, hrname:Hrname}])
    }
    return(
      
        <form onSubmit={addMovie}>
            <h1 className="text-warning">Add Movies</h1>

        <div class="mb-3">
          <label for="name" class="form-label">Movie Name</label>
          <input type="text" class="form-control" name="name" value={name} onChange={updateName}/>
        </div>

        <div class="mb-3">
          <label for="hrname" class="form-label">Hero Name</label>
          <input type="text" class="form-control" name="hrname" value={Hrname} onChange={updateHname}/>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    );
}

export default AddMovie;